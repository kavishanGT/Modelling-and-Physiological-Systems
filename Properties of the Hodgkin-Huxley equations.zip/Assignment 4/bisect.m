function bisect_out = bisect(sub_threshold, sup_threshold,accuracy)

global amp1

while (sup_threshold - sub_threshold > accuracy)
    amp1 = (sub_threshold + sup_threshold)/2;
    value = hhmplot(0,50,1);

    if value < 0 
        sub_threshold = amp1;

    elseif value >0
        sup_threshold = amp1;
    end

    disp('amplitude of amp1 '+ string(amp1)+ '-->'+ string(value))
end
bisect_out  = amp1;